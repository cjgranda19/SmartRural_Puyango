import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class VerResenasPage extends StatefulWidget {
  final String sitioId;

  const VerResenasPage({super.key, required this.sitioId});

  @override
  State<VerResenasPage> createState() => _VerResenasPageState();
}

class _VerResenasPageState extends State<VerResenasPage> {
  List<dynamic> resenas = [];
  Map<String, dynamic>? resumen;
  bool cargando = true;

  @override
  void initState() {
    super.initState();
    cargarDatos();
  }

  Future<void> cargarDatos() async {
    final apiUrl = dotenv.env['API_URL'];

    try {
      final resenasResponse = await http.get(Uri.parse('$apiUrl/resenas/${widget.sitioId}'));
      final resumenResponse = await http.get(Uri.parse('$apiUrl/resumen/${widget.sitioId}'));

      if (resenasResponse.statusCode == 200 && resumenResponse.statusCode == 200) {
        setState(() {
          resenas = json.decode(resenasResponse.body);
          resumen = json.decode(resumenResponse.body);
          cargando = false;
        });
      } else {
        throw Exception('Error al cargar datos');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }

  Icon sentimientoIcono(String sentimiento) {
    switch (sentimiento.toLowerCase()) {
      case 'positivo':
        return const Icon(Icons.sentiment_satisfied, color: Colors.green);
      case 'negativo':
        return const Icon(Icons.sentiment_dissatisfied, color: Colors.red);
      case 'neutral':
        return const Icon(Icons.sentiment_neutral, color: Colors.grey);
      default:
        return const Icon(Icons.help_outline);
    }
  }

  Icon accesibilidadIcono(String nivel) {
    switch (nivel.toLowerCase()) {
      case 'alta':
        return const Icon(Icons.traffic, color: Colors.green);
      case 'media':
        return const Icon(Icons.traffic, color: Colors.amber);
      case 'baja':
        return const Icon(Icons.traffic, color: Colors.red);
      default:
        return const Icon(Icons.help_outline);
    }
  }

  Widget _buildStatChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color, width: 1.5),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Color _getConclussionColor() {
    if (resumen!['conclusion'].contains('🟢')) {
      return Colors.green;
    } else if (resumen!['conclusion'].contains('🔴')) {
      return Colors.red;
    } else {
      return Colors.orange;
    }
  }

  Color _getAccesibilidadColor() {
    switch (resumen!['accesibilidad'].toLowerCase()) {
      case 'alta':
        return Colors.green;
      case 'media':
        return Colors.orange;
      case 'baja':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  List<Widget> _buildRecommendationList(String recomendacion) {
    List<String> items = recomendacion.split(' | ');
    return items.map((item) => Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 6,
            height: 6,
            margin: const EdgeInsets.only(top: 6, right: 8),
            decoration: BoxDecoration(
              color: Colors.purple[400],
              shape: BoxShape.circle,
            ),
          ),
          Expanded(
            child: Text(
              item,
              style: const TextStyle(
                fontSize: 14,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    )).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reseñas del sitio')),
      body: cargando
    ? const Center(child: CircularProgressIndicator())
    : SingleChildScrollView(
        child: Column(
          children: [
            if (resumen != null)
              Card(
                margin: const EdgeInsets.all(12),
                color: Colors.blue[50],
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("🏞️ Resumen Inteligente del Sitio", 
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[800]
                          )),
                      const SizedBox(height: 12),
                      
                      // Estadísticas rápidas
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey[300]!)
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildStatChip("✅ ${resumen!['porcentajes']['positivo']}%", Colors.green),
                            _buildStatChip("😐 ${resumen!['porcentajes']['neutral']}%", Colors.orange),
                            _buildStatChip("❌ ${resumen!['porcentajes']['negativo']}%", Colors.red),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 12),
                      Text("Total de reseñas: ${resumen!['total']}", 
                          style: const TextStyle(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 8),
                      
                      // Conclusión principal
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _getConclussionColor(),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        width: double.infinity,
                        child: Text(
                          resumen!['conclusion'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.white
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      
                      const SizedBox(height: 12),
                      
                      // Información de accesibilidad
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            const Text("🚗 Accesibilidad: ", 
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            accesibilidadIcono(resumen!['accesibilidad']),
                            const SizedBox(width: 8),
                            Text(
                              resumen!['accesibilidad'].toString().toUpperCase(),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: _getAccesibilidadColor(),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Recomendación detallada
                      if (resumen!.containsKey('recomendacion') && resumen!['recomendacion'] != null)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 16),
                            Text("🤖 Recomendación Inteligente:", 
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple[700]
                                )),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.purple[50],
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.purple[200]!)
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: _buildRecommendationList(resumen!['recomendacion']),
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
            const Divider(),
            ...resenas.map((resena) => Card(
                  margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                  child: ListTile(
                    leading: sentimientoIcono(resena['sentimiento']),
                    title: Text(resena['texto']),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Usuario: ${resena['usuario']}'),
                        Text(
                          'Fecha: ${resena['fecha'].substring(0, 10)}',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
